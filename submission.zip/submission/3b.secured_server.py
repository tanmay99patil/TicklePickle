import json
import os
import pickle
def reverse_fun():
      with open("users.json","rb") as f:
        data = f.read()
      
        # d=json.JSONDecoder().decode(data)

        d=json.loads(data)  
        return d

if __name__ == '__main__':
      print(reverse_fun())  